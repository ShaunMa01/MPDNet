from .hgru_function import HgruFunction
