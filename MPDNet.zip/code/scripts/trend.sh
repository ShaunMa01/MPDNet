pred_l=(96 192 336 720)

for i in ${pred_l[@]}
do
    python -u run.py \
        --model DLinear2 \
        --data WTH \
        --seq_len 336 \
        --pred_len $i
done