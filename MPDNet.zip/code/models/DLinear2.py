import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.Autoformer_EncDec import series_decomp
from models.networks import RevIN, series_decomp, FITS, Freq_TVT2
from models.newMPDNet import cal_padding
from hgru import HgruRealV6, Hgru1dV3, BiHgru1d

class Model(nn.Module):
    """
    Paper link: https://arxiv.org/pdf/2205.13504.pdf
    """

    def __init__(self, configs):
        """
        individual: Bool, whether shared model among different variates.
        """
        super(Model, self).__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        # Series decomposition block from Autoformer
        self.decompsition = series_decomp(24)
        self.channels = configs.enc_in
        self.patch_len = 24
        self.Linear_Seasonal = nn.Linear(self.seq_len, self.pred_len)
        self.Linear_Trend = nn.Linear(self.seq_len, self.pred_len)

        self.Linear_Seasonal.weight = nn.Parameter(
            (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len]))
        self.Linear_Trend.weight = nn.Parameter(
            (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len]))
        self.trend_padding = cal_padding(self.seq_len + self.pred_len, self.patch_len)
        self.time_shift = nn.ZeroPad2d((0, 0, 1, -1))
        self.d_model = configs.d_model
        self.hgru = BiHgru1d(configs.d_model)
        self.linear_patch = nn.Linear(self.patch_len, configs.d_model)
        self.linear_patch_re = nn.Linear(configs.d_model, self.patch_len)
        self.revin = RevIN(configs.enc_in)
        self.dropout = nn.Dropout(configs.dropout)
        self.act = nn.GELU()
        self.seasonal = Freq_TVT2(configs)


    def encoder(self, x):
        # x = self.revin(x, 'norm')
        seq_last = x[:, -1:, :].detach()
        x = x - seq_last
        B, L, C = x.shape
        seasonal_init, trend_init = self.decompsition(x)
        seasonal_init, trend_init = seasonal_init.permute(
            0, 2, 1), trend_init.permute(0, 2, 1)
        # seasonal_output = self.Linear_Seasonal(seasonal_init)
        seasonal_output = self.seasonal(seasonal_init.transpose(1, 2)).transpose(1, 2)
        # trend_init = x.permute(0, 2, 1)
        trend_output = self.Linear_Trend(trend_init)

        trend = torch.cat([trend_init, trend_output], dim=-1)
        last = trend[:, :, -1].unsqueeze(-1).repeat(1, 1, self.trend_padding)
        trend = torch.cat([trend, last], dim=-1)
        trend = trend.unfold(dimension=-1, size=self.patch_len, step=self.patch_len)
        trend = trend.reshape(B * C, -1, self.patch_len)
        trend_in = self.linear_patch(trend)
        trend_in = torch.cat([self.time_shift(trend_in[:, :, :self.d_model // 2]), trend_in[:, :, self.d_model // 2:]],
                             dim=-1)
        trend_out = self.hgru(trend_in)
        trend_out = self.linear_patch_re(self.dropout(trend_out))
        trend_out = trend_out.transpose(1, 2).reshape(B, C, -1)
        trend_out = trend_out[:, :, :(self.seq_len + self.pred_len)]
        # trend_output = trend_output + self.dropout(self.act(trend_out[:, :, -self.pred_len:]))
        # trend_output = self.dropout(self.act(trend_out[:, :, -self.pred_len:]))
        trend_output = trend_out[:, :, -self.pred_len:]
        trend_output = self.decompsition(trend_output.transpose(1, 2))[1]
        trend_output = trend_output.transpose(1, 2)
        x = trend_output + seasonal_output
        x = x.permute(0, 2, 1)
        x = x + seq_last
        # x = self.revin(x, 'denorm')
        return x


    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        return self.encoder(x_enc)
