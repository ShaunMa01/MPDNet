import numpy as np
import pandas as pd
from statsmodels.tsa.filters.hp_filter import hpfilter
import matplotlib.pyplot as plt

data = pd.read_csv('../dataset/ETT-small/ETTh1.csv').values
data = data[:, 1:]
len = 720

# data = data[:len, :]
# # norm_data = (data - np.mean(data)) / (np.std(data) + 1e-5)
#
# for i in range(data.shape[1]):
# lamb = 1600#13322500
# _, trend = hpfilter(data, lamb)
# print(trend.shape)
# plt.plot(norm_data)
# plt.plot(trend)
# plt.show()
# norm_data = norm_data - trend
# fft_data = np.fft.rfft(norm_data)
# fft_data = np.abs(fft_data)
# top_k = 5
# top_list = fft_data.argsort()[::-1][0:top_k]
# period = len // top_list
# print(period)
