import torch
import torch.nn as nn
import math
from models.newMPDNet import cal_padding
from hgru import HgruRealV6, Hgru1dV3, BiHgru1d
from models.networks import RevIN
import torch.nn.functional as F

class Transpose(nn.Module):
    def __init__(self, *dims, contiguous=False):
        super().__init__()
        self.dims, self.contiguous = dims, contiguous
    def forward(self, x):
        if self.contiguous: return x.transpose(*self.dims).contiguous()
        else: return x.transpose(*self.dims)

class RMSNorm(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.scale = dim**-0.5
        self.gamma = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        x = x / x.norm(p=2, dim=-1, keepdim=True)
        return self.gamma / self.scale * x

class TrendPredict(nn.Module):
    def __init__(self, seq_len, pred_len, patch_len, d_model, k, dropout):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.trend_init = nn.Linear(seq_len, pred_len)
        self.trend_padding = cal_padding(seq_len + pred_len, patch_len)
        # self.trend_padding = cal_padding(pred_len, patch_len)
        self.linear_patch = nn.Conv1d(in_channels=k, out_channels=d_model, kernel_size=patch_len, stride=patch_len)
        self.linear_patch_re = nn.ConvTranspose1d(in_channels=d_model, out_channels=1, kernel_size=patch_len,
                                                       stride=patch_len)
        self.time_shift = nn.ZeroPad2d((0, 0, 1, -1))
        self.d_model = d_model
        self.hgru = HgruRealV6(d_model)
        # self.hawk = Hawk(d_model)
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(d_model)
        # self.pos = nn.Parameter(torch.randn(1, k, (self.trend_padding + seq_len + pred_len)))

    def forward(self, x):
        B, C, L = x.shape
        trend_pred = self.trend_init(x)
        trend = torch.cat([x, trend_pred], dim=-1)
        # trend = trend_pred
        last = trend[:, :, -1].unsqueeze(-1).repeat(1, 1, self.trend_padding)
        trend = torch.cat([trend, last], dim=-1)
        # trend = trend + self.pos
        # trend = self.norm(trend)
        # trend = trend.unfold(dimension=-1, size=self.patch_len, step=self.patch_len)
        # trend = trend.reshape(B * C, -1, self.patch_len)
        trend_in = self.linear_patch(trend)
        trend_in = trend_in.transpose(1, 2)
        trend_in = torch.cat([self.time_shift(trend_in[:, :, :self.d_model // 2]), trend_in[:, :, self.d_model // 2:]],
                             dim=-1)
        trend_in = self.act(trend_in)
        trend_out = self.hgru(trend_in)
        # trend_out = self.hawk(trend_in)
        # trend_out = trend_in
        # trend_out = self.norm(trend_in + self.dropout(trend_out)).transpose(1, 2)
        # trend_out = self.linear_patch_re(trend_out.transpose(1, 2))
        trend_out = self.linear_patch_re(self.dropout(trend_out.transpose(1, 2)))
        trend_out = trend_out[:, :, :(self.seq_len + self.pred_len)]
        # trend_out = trend_out[:, :, :self.pred_len]
        trend_output = trend_out[:, :, -self.pred_len:]
        return trend_output

class SeasonalPredict(nn.Module):
    def __init__(self, seq_len, pred_len, d_model, k, dropout, enc_in, periods):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.len = (seq_len + pred_len)
        # self.embedding = nn.Conv1d(in_channels=k, out_channels=d_model, kernel_size=3, stride=1, padding=1)
        self.fno = nn.Parameter(0.02 * torch.randn(self.seq_len // 2 + 1, self.pred_len // 2 + 1, dtype=torch.cfloat))
        # self.fno = nn.Parameter(0.02 * torch.randn(self.len // 2 + 1, self.len // 2 + 1, dtype=torch.cfloat))
        # self.pred_proj = nn.Linear(self.seq_len, self.pred_len)
        self.out_proj = nn.Conv1d(in_channels=k, out_channels=1, kernel_size=3, stride=1, padding=1)
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        self.embed = nn.Linear(4, enc_in)
        self.revIn= RevIN(k*enc_in)
        # self.periodEmbedd = self._getPeriodEmbedd(periods)#nn.Parameter(torch.randn(1, 1, k, seq_len + pred_len))
        # self.norm= nn.Sequential(Transpose(1, 2), nn.BatchNorm1d(d_model), Transpose(1, 2))
        # self.norm = nn.LayerNorm(d_model)
        # self.length_ratio = (seq_len + pred_len) // seq_len
        # self.dominance_freq = seq_len // 2
        # self.fno = nn.Parameter(0.02 * torch.randn(self.dominance_freq,
        #                                            self.dominance_freq * self.length_ratio, dtype=torch.cfloat))


    def forward(self, x, x_mark=None):
        # x = self.embedding(x)
        # x = self.dropout(self.act(x))
        # x = self.act(x)
        B, D, K, L = x.shape
        # x = x.reshape(B, -1, L).transpose(1, 2)
        # x = self.revIn(x, 'norm').transpose(1, 2)

        # zeros = torch.zeros([B, D, K, self.pred_len], device=x.device)
        # x = torch.cat([x, zeros], dim=-1)
        # pos = self.embed(x_mark).transpose(1, 2)
        # x = x + pos.unsqueeze(dim=2) #+ self.periodEmbedd.to(x.device)
        x = x.reshape(B*D, K, -1)
        x_fft = torch.fft.rfft(x, dim=-1)
        out_fft = torch.einsum("bcx,xl->bcl", x_fft, self.fno)
        output = torch.fft.irfft(out_fft, dim=-1)
        # output = output.reshape(B, D*K, -1).transpose(1, 2)
        # output = self.revIn(output, 'denorm')
        # output = output.transpose(1, 2).reshape(B*D, K, -1)
        # output = self.act(output)
        # output = self.norm(output.transpose(1, 2)).transpose(1, 2)
        # output = self.pred_proj(x)
        out = self.out_proj(output)

        return out[:, :, -self.pred_len:]

class LoaclExtract(nn.Module):
    def __init__(self, seq_len, pred_len, d_model, p, kernel_list):
        super().__init__()
        self.inPadding = cal_padding(seq_len, p)
        self.in_nums = (seq_len + p - 1) // p
        self.out_nums = (pred_len + p - 1) // p
        self.period = p
        self.pred_len = pred_len
        self.conv1 = nn.Conv1d(self.in_nums, d_model, kernel_size=3, padding=3 // 2)
        self.act = nn.GELU()
        self.conv2 = nn.Conv1d(d_model, self.out_nums, kernel_size=3, padding=3 // 2)


    def forward(self, x):
        seasonal_padding = torch.zeros([x.shape[0], self.inPadding]).to(x.device)
        seasonal = torch.cat([x, seasonal_padding], dim=-1)
        seasonal = seasonal.unfold(dimension=1, size=self.period, step=self.period)
        seasonal_out = self.conv1(seasonal)
        seasonal_out = self.act(seasonal_out)
        seasonal_out = self.conv2(seasonal_out)
        seasonal_out = seasonal_out.transpose(1, 2).reshape(-1, self.out_nums * self.period)[:, :self.pred_len]
        return seasonal_out



class LocalPredict(nn.Module):
    def __init__(self, k, periods, seq_len, pred_len, d_model, kernel_list):
        super().__init__()
        self.k = k
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.backbone = nn.ModuleList([LoaclExtract(seq_len, pred_len, d_model, periods[i], kernel_list)
                                       for i in range(self.k)])
        self.out_proj = nn.Conv1d(in_channels=k, out_channels=1, kernel_size=3, stride=1, padding=1)



    def forward(self, x):
        B, D, K, L = x.shape
        x = x.reshape(B*D, K, L)
        local = []
        for i in range(self.k):
            out = self.backbone[i](x[:, i, :])
            local.append(out)
        local = torch.stack(local, dim=1)
        return self.out_proj(local)


# from accelerated_scan.warp import scan
from torch.nn.functional import softplus, gelu
from hgru.hgru_real_cuda import HgruRealFunction
triton_parallel_scan = HgruRealFunction.apply

class Hawk(nn.Module):
    def __init__(self, dim, act_fun="gelu", causal=True, use_triton=True, kernel_size=4, expansion_factor=1.5):
        super().__init__()
        # params = locals()
        # print_params(**params)
        # embed_dim = int(dim * expansion_factor)
        embed_dim = dim
        self.input = nn.Linear(dim, 2 * embed_dim, bias=False)
        self.conv = nn.Conv1d(in_channels=embed_dim, out_channels=embed_dim, bias=True,
                              kernel_size=kernel_size, groups=embed_dim, padding=kernel_size - 1)
        self.gates = nn.Linear(embed_dim, 2*embed_dim, bias=True)
        self.forget_base = nn.Parameter(torch.linspace(-4.323, -9, embed_dim))
        self.output = nn.Linear(embed_dim, dim, bias=False)
        self.alpha_log_scale = nn.Parameter(torch.tensor([8]).log(), requires_grad=False)
        self.scan = HgruRealFunction.apply if not use_triton else triton_parallel_scan
        with torch.no_grad():
            self.input.weight.normal_(std=dim ** -0.5)
            self.gates.weight.normal_(std=embed_dim ** -0.5)
            self.output.weight.normal_(std=embed_dim ** -0.5)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        _N, T, _C = x.shape
        gate, x = self.input(x).chunk(2, dim=-1)
        x = self.conv(x.mT)[..., :T].mT

        # RG-LRU: linear recurrent unit with input-dependent gating
        forget, input = self.gates(x).chunk(2, dim=-1)
        alpha = (-self.alpha_log_scale.exp() * softplus(self.forget_base) * forget.sigmoid()).exp()
        beta = (1 - alpha ** 2 + 1e-6).sqrt()  # stabilizes variance
        x = beta * input.sigmoid() * x
        h = self.scan(x, alpha)
        # h = self.norm(h)
        # h = scan(alpha.mT.contiguous(), x.mT.contiguous()).mT
        x = self.output(gelu(gate) * h)

        return x

class GatedMLP(nn.Module):
    def __init__(self, dim=1024, expansion_factor=2):
        super().__init__()
        hidden = int(dim * expansion_factor)
        self.grow = nn.Linear(dim, 2 * hidden, bias=False)
        self.shrink = nn.Linear(hidden, dim, bias=False)

        with torch.no_grad():
            self.grow.weight.normal_(std=dim**-0.5)
            self.shrink.weight.normal_(std=hidden**-0.5)

    def forward(self, x):
        gate, x = self.grow(x).chunk(2, dim=-1)
        x = gelu(gate) * x
        return self.shrink(x)

class RMSNorm(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.scale = dim**-0.5
        self.gamma = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        x = x / x.norm(p=2, dim=-1, keepdim=True)
        return self.gamma / self.scale * x

class Griffin(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        self.hawk_norm = RMSNorm(dim=d_model)
        self.hawk = Hawk(dim=d_model)
        self.hawk_gmlp_norm = RMSNorm(dim=d_model)
        self.hawk_gmlp = GatedMLP(dim=d_model)

    def forward(self, x):
        x = x + self.hawk(self.hawk_norm(x))
        x = x + self.hawk_gmlp(self.hawk_gmlp_norm(x))
        return x

