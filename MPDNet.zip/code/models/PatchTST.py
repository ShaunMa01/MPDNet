import torch
import torch.nn as nn
from models.PatchTST_backbone import PatchTST_backbone

class PatchTST(nn.Module):
    def __init__(self, configs, index):
        super().__init__()
        self.model = PatchTST_backbone(c_in=configs.enc_in, context_window=configs.seq_len,
                                       target_window=configs.pred_len,
                                       patch_len=configs.period[index], stride=configs.period[index],
                                       n_layers=configs.e_layers, d_model=configs.d_model,
                                       n_heads=configs.n_heads, d_ff=configs.d_ff,
                                       dropout=configs.dropout)

    def forward(self, x):
        x = x.permute(0, 2, 1)  # x: [Batch, Channel, Input length]
        x = self.model(x)
        x = x.permute(0, 2, 1)  # x: [Batch, Input length, Channel]
        return x