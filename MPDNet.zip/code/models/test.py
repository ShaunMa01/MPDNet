import torch
import torch.nn as nn
from scipy.fftpack import next_fast_len
import torch.fft as fft
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.seasonal import STL
# seq = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0, 1.0])
# diff2 = torch.tensor([1.0, -1.0])
#
# kernel = torch.tensor([[1.0, -1.0]]).view(1, 1, 2)
# conv = nn.Conv1d(in_channels=1, out_channels=1, kernel_size=2, bias=False)
# conv.weight = nn.Parameter(kernel, requires_grad=False)
#
# print(conv(seq.reshape(1, 1, -1)))
from matplotlib.font_manager import FontProperties
path1 = '../dataset/electricity/electricity.csv'
# path1 = '../dataset/traffic/traffic.csv'
data1 = np.array(pd.read_csv(path1))
data1 = data1[:96, 4]

data1 = data1 - np.mean(data1)
index = np.fft.rfftfreq(data1.shape[0])
fft_data = np.fft.rfft(data1, norm='ortho')
fft_data = np.abs(fft_data)
max_index = np.argsort(fft_data)[-2:]
print(max_index)
print(fft_data[max_index])
print(index[max_index])
plt.plot(index, fft_data)
plt.title('Frequency Spectrum')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude')

plt.show()
# data1 = data1.reshape(24, -1)
# plt.boxplot(data1,0,'',showmeans=False,
#                           vert=True  # vertical box aligmnent
#                           )
# plt.xlabel('day index')
# plt.ylabel('electricity consumption per hour')
# plt.show()
# data1 = data1[:721, 1]
# font = FontProperties(fname=r"/root/.fonts/simhei.ttf", size=14)
# data1 = data1 - np.mean(data1, keepdims=True)
#*********
# len = 24
# s1 = data1[:len]
# s2 = data1[len:2*len]
# s3 = data1[2*len:3*len]
# # s4 = data1[3*len:4*len]
# # # plt.plot(s1)
# plt.plot(s1, label='Day1', linewidth=2)
# plt.plot(s2, label='Day2', linewidth=2)
# plt.plot(s3, label='Day3', linewidth=2)
# # plt.plot(s1, label='Day3', linewidth=2)
# plt.xlabel('hour')
# plt.ylabel('electricity consumption per hour')
# plt.legend()
# plt.show()
#*********

# font = FontProperties(fname=r"/root/.fonts/simhei.ttf", size=14)
# plt.plot(data1)
# plt.show()
#
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] = False
# decomposition = STL(data1, period=24).fit()
# remove_trend = data1 - decomposition.trend
# remove_sea = remove_trend - decomposition.seasonal
# plot_acf(data1, lags=96)
# plt.title("数据初始自相关图", fontproperties=font)
# plt.show()
# plot_acf(remove_trend, lags=96)
# plt.title("去除趋势项后自相关图", fontproperties=font)
# plt.show()
# plot_acf(remove_sea, lags=96)
# plt.title("去除趋势和季节项后自相关图", fontproperties=font)
# plt.show()
# result = adfuller(data1)
# print(result)


