import torch
import torch.nn as nn
from models.networks import FFT_for_Period, RevIN, series_decomp, TSMamba
from hgru import HgruRealV6
from models.newMPDNet import MPDNet
from models.iTransformer import Backbone

class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()
        self.k = configs.k
        self.linear = nn.Linear(1, 1)
        self.revin = RevIN(configs.enc_in)
        self.period = configs.period
        # self.decomp = nn.ModuleList([series_decomp(self.period[i]) for i in range(self.k)])
        # self.backbone = nn.ModuleList([TSMamba(configs, self.decomp[i], self.period[i]) for i in range(self.k)])
        # self.backbone = nn.ModuleList([HgruRealV6(configs.enc_in, configs.pred_len // seq_) for i in range(self.k)])
        # self.out_proj = nn.
        self.backbone = nn.ModuleList([MPDNet(configs, i) for i in range(self.k)])
        self.out_proj = nn.Linear(self.k, 1)
        self.itransformer = Backbone(configs)


    def forward(self, x, x_mark, y_true, y_mark, others):
        B, L, C = x.shape
        x = self.revin(x, 'norm')
        scale_list, scale_weight = FFT_for_Period(x, 5)
        res = []
        for i in range(self.k):
            out = self.backbone[i](x, y_mark)
            res.append(out)
        res = torch.stack(res, dim=-1)
        # res = torch.mean(res, dim=-1)
        res = self.out_proj(res).squeeze(dim=-1)
        # res = self.itransformer(res)
        res = self.revin(res, 'denorm')
        return res

