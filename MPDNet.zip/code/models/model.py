import torch
import torch.nn as nn
from models.embed import DataEmbedding, DataEmbedding_wo_pos, TokenEmbedding
from models.local_global import Seasonal_Prediction, series_decomp_multi, series_decomp, RevIN, TVT, TVT2, Freq_TVT, patchAttention, EMA
from hgru import HgruRealV6
import matplotlib.pyplot as plt
from scipy.fftpack import next_fast_len
from models.ESM import ExponentialSmoothing

def cal_cov(x):
    length = x.shape[1]
    fast_len = next_fast_len(2 * length - 1)
    x_fft = torch.fft.rfft(x, fast_len, dim=1)
    out_fft = x_fft * x_fft.conj()
    out = torch.fft.irfft(out_fft, fast_len, dim=1)
    out = out #/ length
    out = out.roll((-1,), dims=(1,))
    idx = torch.as_tensor(range(fast_len - length, fast_len)).to(out.device)
    out = out.index_select(1, idx)
    return torch.flip(out, dims=[1])

def cal_autocor(x):
    B, L, D = x.shape
    zeros = torch.zeros([B, L-1, D]).to(x)
    div = torch.arange(L).to(x) + 1
    div = torch.flip(div, dims=[0])
    inv_x = torch.flip(x, dims=[1])
    x = torch.cat([x, zeros], dim=1)
    inv_x = torch.cat([inv_x, zeros], dim=1)
    x = x.unfold(dimension=1, size=L, step=1)
    inv_x = inv_x.unfold(dimension=1, size=L, step=1)
    x = torch.sum(x**2, dim=-1)#/div.reshape(1, -1, 1)
    inv_x = torch.sum(inv_x ** 2, dim=-1) #/ div.reshape(1, -1, 1)
    out = (x ** 0.5) * (inv_x ** 0.5)
    return out

def cal_alpha(X, A, order=None):
    cov_x = cal_cov(X)
    cov_a = cal_cov(A)
    # div_x = cal_autocor(X)
    # div_a = cal_autocor(A)
    # cor_x = cov_x / div_x
    # cor_x = torch.where(torch.abs(cor_x) > 1, torch.tensor([0]).to(cor_x), cor_x)
    # cor_x = torch.where(torch.abs(cor_x) < 0.8, torch.tensor([0]).to(cor_x), cor_x)
    # cor_a = cov_a / div_a
    # cor_a = torch.where(torch.abs(cor_a) > 1, torch.tensor([0]).to(cor_a), cor_a)
    # cor_a = torch.where(torch.abs(cor_a) < 0.8, torch.tensor([0]).to(cor_a), cor_a)
    if order is not None:
        cov_x = cov_x[:, :order, :]
        cov_a = cov_a[:, :order, :]
    else:
        cov_x = cov_x[:, :, :]
        cov_a = cov_a[:, :cov_x.shape[1], :]
    alpha = torch.sum(cov_x * cov_a, dim=1, keepdim=True) / (torch.sum(cov_a * cov_a, dim=1, keepdim=True) + 1e-6)
    # alpha = torch.clamp(alpha, 0)
    alpha = alpha ** 0.5
    return alpha

class MICN(nn.Module):
    def __init__(self, dec_in, c_out, seq_len, label_len, out_len,
                 d_model=512, n_heads=8,d_layers=2,
                 dropout=0.0,embed='fixed', freq='h',
                 device=torch.device('cuda:0'), mode='regreR_A',
                 decomp_kernel=[33], conv_kernel=[12, 24], isometric_kernel=[18, 6],):
        super(MICN, self).__init__()

        self.pred_len = out_len
        self.seq_len = seq_len
        self.c_out = c_out
        self.decomp_kernel = decomp_kernel
        self.mode = mode

        self.decomp_multi = series_decomp_multi(decomp_kernel)
        self.decomp = series_decomp(decomp_kernel[0])
        # embedding
        self.dec_embedding = DataEmbedding(dec_in, d_model, embed, freq, dropout, True)
        self.trend_embedding = DataEmbedding(dec_in, d_model, embed, freq, dropout, True)
        # self.dec_te = TokenEmbedding(dec_in, d_model)

        self.conv_trans = Seasonal_Prediction(embedding_size=d_model, n_heads=n_heads, dropout=dropout,
                                     d_layers=d_layers, decomp_kernel=decomp_kernel, c_out=c_out, conv_kernel=conv_kernel,
                                     isometric_kernel=isometric_kernel, mode='local', device=device)
        self.conv_trend = Seasonal_Prediction(embedding_size=d_model, n_heads=n_heads, dropout=dropout,
                                              d_layers=d_layers, decomp_kernel=decomp_kernel, c_out=c_out,
                                              conv_kernel=conv_kernel,
                                              isometric_kernel=isometric_kernel, mode='local', device=device)
        self.regression = nn.Linear(seq_len, out_len)
        self.projection = nn.Linear(seq_len, out_len)
        self.regression.weight = nn.Parameter((1/out_len) * torch.ones([out_len, seq_len]), requires_grad=True)
        self.revin_layer = RevIN(dec_in)
        self.revin_layer2 = RevIN(dec_in)
        self.tvt = TVT(seq_len, out_len, n_heads, dropout,  d_model*2, dec_in, freq)
        # self.tvt = nn.Linear(seq_len, out_len)
        self.tvt2 = TVT2(seq_len, out_len, n_heads, dropout, d_model * 2, dec_in, freq)

        self.freq_tvt = Freq_TVT(seq_len, out_len, dropout, 128, d_model * 2, dec_in, freq)


        self.trend = nn.Sequential(
            nn.Linear(seq_len, d_model),
            nn.ReLU(),
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, out_len)
        )
        self.patchAtten = patchAttention(seq_len, out_len, dec_in, freq, 128, 16, 8, 4, 256, dropout)
        # self.dish = DishTS('standard', dec_in, seq_len)
        self.alpha = nn.Parameter(torch.ones(dec_in))
        # self.ema = EMA(dec_in, 1, dropout)
        self.ema = ExponentialSmoothing(1, dec_in, dropout)
        self.drop = nn.Dropout(dropout)

        # self.cla = cla_alpha('wavelet', 'haar')



    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, his_data,
                enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):

        # trend-cyclical prediction block: regre or mean
        # x_enc = self.revin_layer(x_enc, 'norm')
        # _, trend = self.decomp_multi(x_enc)
        # x_enc = self.revin_layer(x_enc, 'norm')
        # seasonal_init_enc = self.revin_layer(x_enc, 'norm')

        seasonal_init_enc, trend = self.decomp_multi(x_enc)

        # trend = x_enc
        # his_data, _ = self.decomp(his_data)
        # index = torch.zeros(his_data.shape[0], 1, his_data.shape[-1], device=his_data.device, dtype=torch.float32)
        # result = torch.zeros(his_data.shape[0], self.seq_len+self.pred_len, his_data.shape[-1], device=his_data.device, dtype=torch.float32)
        # min = torch.full((his_data.shape[0], 1, his_data.shape[-1]), 0x3f3f3f3f, device=his_data.device, dtype=torch.float32)
        # for i in range(0, his_data.shape[1]-self.seq_len-self.pred_len-1, 1):
        #     pre_data = his_data[:, i:i+self.seq_len, :]
        #     tmp_data = his_data[:, i:i+self.seq_len+self.pred_len, :]
        #     esim = torch.sum((seasonal_init_enc - pre_data) ** 2, dim=1, keepdim=True) ** 0.5
        #     index = torch.where(esim<min, torch.tensor(i,  device=his_data.device, dtype=torch.float32), index)
        #     min = torch.where(esim<min, esim, min)
        #     result = torch.where(esim<min, result, tmp_data)
            # his_data = his_data.unfold(dimension=1, size=self.seq_len+self.pred_len, step=1)
            # B, N, C, L = his_data.shape
            # his_data = his_data.transpose(1, 2)
            # pre_data = his_data[:, :, :, :self.seq_len]
            # pre_input = seasonal_init_enc.transpose(1, 2).unsqueeze(dim=2).repeat(1, 1, pre_data.shape[2], 1)

        # esim = (pre_input - pre_data)
        # index = torch.argmax(esim, dim=-1)
        # print(index)

        # trend = x_enc
        # for i in range(trend.shape[-1]):
        #     print("dim: " + str(i))
        # for j in range(trend.shape[0]):
        #     print("batch: " + str(j))
        #     plt.plot(x_enc[j, :, -1].cpu().detach().numpy())
        #     plt.plot(trend[j, :, -1].cpu().detach().numpy())
        #     plt.plot(seasonal_init_enc[j, :, -1].cpu().detach().numpy())
        #     plt.show()
        if self.mode == 'regre':


          # u  zeros = torch.zeros([x_dec.shape[0], self.pred_len, x_dec.shape[2]], device=x_enc.device)
          #   means = torch.mean(x_enc, dim=1).unsqueeze(1).repeat(1, self.pred_len, 1)
          #   trend = torch.cat([trend, means], dim=1)
          #   trend = self.drop(self.ema(trend.nsqueeze(dim=-1))).squeeze(dim=-1)

            trend = self.revin_layer(trend, 'norm')


            #
            # trend = self.tvt(trend, x_mark_dec)
            trend = self.trend(trend.transpose(1, 2)).transpose(1, 2)
            # seasonal_init_enc = self.revin_layer(seasonal_init_enc, 'norm')
            # dec_out = self.tvt(seasonal_init_enc, x_mark_dec)
            # dec_out = self.revin_layer(dec_out, 'denorm')
            # trend = self.patchAtten(trend, x_mark_dec)
            # trend = self.attention(trend, x_mark_dec)
            # trend = self.multi_tvt(trend, x_mark_dec)
            # zeros = torch.zeros([x_dec.shape[0], self.pred_len, x_dec.shape[2]], device=x_enc.device)
            # trend = torch.cat([trend[:, -self.seq_len:, :], zeros], dim=1)
            # trend = self.trend_embedding(trend, x_mark_dec)
            # trend = self.conv_tvt(trend, x_mark_dec)
            # trend = self.trend(trend.transpose(1, 2)).transpose(1, 2)
            # # # _, trend = self.decomp(trend)
            # #
            trend = self.revin_layer(trend, 'denorm')
        elif self.mode == 'mean':
            mean = torch.mean(x_enc, dim=1).unsqueeze(1).repeat(1, self.pred_len, 1)
            seasonal_init_enc, trend = self.decomp_multi(x_enc)
            trend = torch.cat([trend[:, -self.seq_len:, :], mean], dim=1)

        # seasonal_init_enc = x_enc
        # seasonal_init_enc = self.revin_layer2(seasonal_init_enc, 'norm')
        # embedding
        # seasonal_init_enc = self.revin_layer2(seasonal_init_enc, 'norm')
        # trend = self.revin_layer2(trend, 'norm')

        zeros = torch.zeros([x_dec.shape[0], self.pred_len, x_dec.shape[2]], device=x_enc.device)
        seasonal_init_dec = torch.cat([seasonal_init_enc[:, -self.seq_len:, :], zeros], dim=1)
        # trend = torch.cat([trend[:, -self.seq_len:, :], zeros], dim=1)
        # seasonal_init_dec = seasonal_init_enc


        # dec_out = self.dec_embedding(seasonal_init_dec, x_mark_dec)
        # dec_out = self.conv_trans(dec_out, x_mark_dec)


        dec_out = self.freq_tvt(seasonal_init_dec, x_mark_dec)
        # trend = self.freq_tvt(trend, x_mark_dec)
        # trend = self.revin_layer2(trend, 'denorm')
        # dec_out = dec_out[:, -self.pred_len:, :]
        # dec_out = dec_out / (torch.std(dec_out, dim=1, keepdim=True) + 1e-6) * torch.std(seasonal_init_enc, dim=1, keepdim=True)
        #
        # dec_out = dec_out - torch.mean(dec_out, dim=1, keepdim=True)
        # alpha = cal_alpha(seasonal_init_enc, dec_out)
        # dec_out = dec_out * alpha.detach()
        # tmp = torch.cat([seasonal_init_enc[:, -self.seq_len:, :], dec_out[:, -self.pred_len:, :]], dim=1)
        # for j in range(trend.shape[0]):
        #     print("batch: " + str(j))
        #     plt.plot(tmp[j, :, -1].cpu().detach().numpy())
        #     plt.show()
        # dec_out = self.conv_tvt(seasonal_init_dec, x_mark_dec)
        # dec_out = dec_out[:, -self.pred_len:, :]


        # dec_out = self.revpsd(dec_out, 'denorm')
        # dec_out = self.revin_layer2(dec_out,'denorm')
        # ratio = (torch.abs(seasonal_init_enc)).mean(dim=1) / (torch.abs(dec_out)).mean(dim=1)
        # ratio = ratio.unsqueeze(dim=1).expand(-1, self.pred_len, -1)
        # dec_out = dec_out[:, -self.pred_len:, :]
        # dec_out = dec_out * ratio #* self.alpha

        # dec_out = self.revin_layer2(dec_out, 'denorm')
        # dec_out = (dec_out[:, -self.pred_len:, :] * self.alpha + trend[:, -self.pred_len:, :] * self.beta) / (self.alpha + self.beta)
        dec_out = dec_out[:, -self.pred_len:, :] + trend[:, -self.pred_len:, :]
        # dec_out = trend[:, -self.pred_len:, :]

        return dec_out


if __name__=="__main__":
    a = torch.tensor([-1, 0, 1])
    out = cal_autocor(a.reshape(1, -1, 1))
    print(a)