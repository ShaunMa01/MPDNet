import torch.nn as nn
import torch
import matplotlib.pyplot as plt
import math
from torch.nn.modules import MultiheadAttention
import torch.nn.functional as F
from einops import rearrange
from scipy.fftpack import next_fast_len
#import seaborn as sns
# from models.embed import PositionalEmbedding

# class moving_avg(nn.Module):
#     """
#     Moving average block to highlight the trend of time series
#     """
#
#     def __init__(self, kernel_size, stride):
#         super(moving_avg, self).__init__()
#         self.kernel_size = kernel_size
#         self.avg = nn.AvgPool1d(kernel_size=kernel_size, stride=stride, padding=0)
#
#     def forward(self, x):
#         # x shape: batch,seq_len,channels
#         # padding on the both ends of time series
#         front = x[:, 0:1, :].repeat(1, (self.kernel_size - 1) // 2, 1)
#         end = x[:, -1:, :].repeat(1, (self.kernel_size - 1) // 2, 1)
#         x = torch.cat([front, x, end], dim=1)
#         x = self.avg(x.permute(0, 2, 1))
#         x = x.permute(0, 2, 1)
#         return x
class ScaledSinuEmbedding(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.scale = nn.Parameter(torch.ones(1,))
        inv_freq = 1. / (10000 ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer('inv_freq', inv_freq)

    def forward(self, x):
        n, device = x.shape[1], x.device
        t = torch.arange(n, device = device).type_as(self.inv_freq)
        sinu = torch.einsum('i , j -> i j', t, self.inv_freq)
        emb = torch.cat((sinu.sin(), sinu.cos()), dim = -1)
        return emb * self.scale

class moving_avg(nn.Module):
    """
    Moving average block to highlight the trend of time series
    """
    def __init__(self, kernel_size, stride):
        super(moving_avg, self).__init__()
        self.kernel_size = kernel_size
        self.avg = nn.AvgPool1d(kernel_size=kernel_size, stride=stride, padding=0)

    def forward(self, x):
        # padding on the both ends of time series
        front = x[:, 0:1, :].repeat(1, self.kernel_size - 1-math.floor((self.kernel_size - 1) // 2), 1)
        end = x[:, -1:, :].repeat(1, math.floor((self.kernel_size - 1) // 2), 1)
        x = torch.cat([front, x, end], dim=1)
        x = self.avg(x.permute(0, 2, 1))
        x = x.permute(0, 2, 1)
        return x

class series_decomp(nn.Module):
    """
    Series decomposition block
    """

    def __init__(self, kernel_size):
        super(series_decomp, self).__init__()
        self.moving_avg = moving_avg(kernel_size, stride=1)

    def forward(self, x):
        moving_mean = self.moving_avg(x)
        res = x - moving_mean
        return res, moving_mean


class series_decomp_multi(nn.Module):
    """
    Series decomposition block
    """

    def __init__(self, kernel_size):
        super(series_decomp_multi, self).__init__()
        self.kernel_size = kernel_size
        self.moving_avg = [moving_avg(kernel, stride=1) for kernel in kernel_size]

    def forward(self, x):
        moving_mean = []
        res = []
        for func in self.moving_avg:
            moving_avg = func(x)
            moving_mean.append(moving_avg)
            sea = x - moving_avg
            res.append(sea)

        sea = sum(res) / len(res)
        moving_mean = sum(moving_mean) / len(moving_mean)
        return sea, moving_mean


class FeedForwardNetwork(nn.Module):
    def __init__(self, hidden_size, filter_size, dropout_rate=0.1):
        super(FeedForwardNetwork, self).__init__()

        self.layer1 = nn.Linear(hidden_size, filter_size)
        self.relu = nn.GELU()

        self.dropout = nn.Dropout(dropout_rate)
        self.layer2 = nn.Linear(filter_size, hidden_size)

        self.conv1 = nn.Conv1d(in_channels=hidden_size, out_channels=filter_size, kernel_size=1, bias=False)
        self.conv2 = nn.Conv1d(in_channels=filter_size, out_channels=hidden_size, kernel_size=1, bias=False)

        self.initialize_weight(self.layer1)
        self.initialize_weight(self.layer2)
        self.initialize_conv(self.conv1)
        self.initialize_conv(self.conv2)

    def forward(self, x):
        x = self.layer1(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.layer2(x)

        # x = self.conv1(x.transpose(1, 2))
        # x = self.relu(x)
        # x = self.dropout(x)
        # x = self.conv2(x).transpose(1, 2)
        return x

    def initialize_conv(self, x):
        if isinstance(x, nn.Conv1d):
            # nn.init.kaiming_normal_(x.weight, mode='fan_out', nonlinearity='relu')
            nn.init.kaiming_uniform_(x.weight, a=math.sqrt(5))
    def initialize_weight(self, x):
        nn.init.xavier_uniform_(x.weight)
        if x.bias is not None:
            nn.init.constant_(x.bias, 0)


class MIC(nn.Module):
    """
    MIC layer to extract local and global features
    """
    def __init__(self, feature_size=512, n_heads=8, dropout=0.05, decomp_kernel=[32], conv_kernel=[24], isometric_kernel=[18, 6], mode=None, device='cuda'):
        super(MIC, self).__init__()
        self.src_mask = None
        self.conv_kernel = conv_kernel
        self.isometric_kernel = isometric_kernel
        self.device = device
        
        # isometric convolution
        self.isometric_conv = nn.ModuleList([nn.Conv1d(in_channels=feature_size, out_channels=feature_size,
                                                   kernel_size=i,padding=0,stride=1)
                                        for i in isometric_kernel])
        # self.isometric_conv = nn.ModuleList([nn.Linear(i, i) for i in isometric_kernel])

        # downsampling convolution: padding=i//2, stride=i
        self.conv = nn.ModuleList([nn.Conv1d(in_channels=feature_size, out_channels=feature_size,
                                             kernel_size=i,padding=0, stride=i)
                                  for i in conv_kernel])

        # upsampling convolution
        self.conv_trans = nn.ModuleList([nn.ConvTranspose1d(in_channels=feature_size, out_channels=feature_size,
                                                            kernel_size=i,padding=0,stride=i)
                                        for i in conv_kernel])
        self.time_conv = nn.ModuleList([nn.Conv1d(in_channels=4, out_channels=feature_size,
                                                            kernel_size=3, padding=1,stride=1)
                                        for i in conv_kernel])

        self.decomp = nn.ModuleList([series_decomp(k) for k in decomp_kernel])
        self.merge = torch.nn.Conv2d(in_channels=feature_size, out_channels=feature_size, kernel_size=(len(self.conv_kernel), 1))

        self.fnn = FeedForwardNetwork(feature_size, feature_size*4, dropout)
        self.fnn_norm = torch.nn.LayerNorm(feature_size)

        self.norm1 = torch.nn.LayerNorm(feature_size)
        self.norm2 = torch.nn.LayerNorm(feature_size)
        self.norm3 = torch.nn.LayerNorm(feature_size)
        self.act = torch.nn.GELU()
        self.act2 = torch.nn.Tanh()
        self.drop = torch.nn.Dropout(0.2)
        self.project = nn.Linear(32, 16)


        # self.norm3 = torch.nn.LayerNorm([16, feature_size])
        # self.norm4 = torch.nn.LayerNorm([16, feature_size])
        # self.norm5 = torch.nn.LayerNorm([192, feature_size])
        self.decompse = series_decomp(24)
        self.pos = ScaledSinuEmbedding(feature_size)
        self.padding = nn.ConstantPad1d(padding=(5, 5), value=0)
        scale = 1 / (feature_size * feature_size)
        self.fno = nn.Parameter(0.02 * torch.randn(feature_size, feature_size, 97, dtype=torch.cfloat))
        self.fft_linear1 = nn.Parameter(0.02 * torch.randn(feature_size, 97, dtype=torch.cfloat))
        self.fft_linear2 = nn.Parameter(0.02 * torch.randn(feature_size, 97, dtype=torch.cfloat))
        self.gate_linear = nn.Linear(192,192)
        self.gate = nn.Tanh()
        self.Lambda = nn.Parameter(torch.zeros(feature_size))
        self.alpha = nn.Parameter(torch.zeros(16))
        self.mode = mode
        self.freqPattern = nn.Parameter(0.02 * torch.randn(feature_size, 97, dtype=torch.cfloat))

    def conv_trans_conv(self, input, conv1d, conv1d_trans, isometric, x_mark, time_conv):
        batch, seq_len, channel = input.shape
        # x = self.norm1(input)
        x = input.permute(0, 2, 1)
        #
        # x_mark = x_mark.permute(0, 2, 1)
        # time_weight = time_conv(x_mark)
        # time_weight = self.padding(time_weight)
        # time_weight = time_weight.unfold(dimension=2, size=12, step=12)
        # tmp_x1 = self.padding(x).unfold(dimension=2, size=12, step=12)
        # x_time = torch.mul(tmp_x1, time_weight).sum(dim=-1)
        # x_time = self.drop(self.norm3(self.act2(x_time).transpose(1, 2)).transpose(1,2))
        # gate = self.gate(self.gate_linear(x_time))

        # x = x * (1 - self.Lambda) + x_time * self.Lambda
        # x = self.bn3(x)
        # x_mark = x_mark.permute(0, 2, 1)
        # time_weight = time_conv(x_mark)
        # x = x + time_weight
        # # downsampling convolution
        x1 = self.drop(self.act2(conv1d(x)))



        # x_mark = x_mark.permute(0, 2, 1)
        # time_weight = time_conv(x_mark)
        # x1 = self.drop(self.act2(conv1d(time_weight)))
        # time_weight = self.padding(time_weight)
        # time_weight = time_weight.unfold(dimension=2, size=self.conv_kernel[0], step=self.conv_kernel[0])
        # tmp_x1 = self.padding(x).unfold(dimension=2, size=self.conv_kernel[0], step=self.conv_kernel[0])
        # x_time = torch.mul(tmp_x1, time_weight).sum(dim=-1)
        # x_time = self.drop(self.act2(conv1d(time_weight)))
        # # x1 = x1 + self.drop(self.act2(x_time))
        # # x1 = self.norm3(x1.transpose(1, 2)).transpose(1, 2)
        # # x = x + self.drop(x_time)
        # # x = x.permute(0, 2, 1)
        #
        x = x1
        # x = x1 * self.gate(x_time)
        # x = x1 + time_weight * self.alpha
        # isometric convolution
        # zeros = torch.zeros((x.shape[0], x.shape[1], x.shape[2]-1), device=self.device)
        # x = torch.cat((zeros, x), dim=-1)
        # x = self.drop(self.act2(isometric(x)))
        # x = self.norm1((x + x1).permute(0, 2, 1)).permute(0, 2, 1)
        # # upsampling convolution
        x = self.drop(self.act2(conv1d_trans(x)))
        x = self.norm2(x.permute(0, 2, 1) + input)


        # x = self.drop(self.act2(self.norm1(conv1d(x).permute(0, 2, 1)))).permute(0, 2, 1)
        # x1 = x
        # zeros = torch.zeros((x.shape[0], x.shape[1], x.shape[2] - 1), device=self.device)
        # x = torch.cat((zeros, x), dim=-1)
        # x = self.drop(self.act2(self.norm2(isometric(x).permute(0, 2, 1)))).permute(0, 2, 1)
        # x = x + x1
        # x = self.drop(self.act2(self.norm3(conv1d_trans(x).permute(0, 2, 1))))
        # x = x + input
        return x

    def cal_global(self, input):
        x = input.transpose(1, 2)
        x = torch.fft.rfft(x, dim=-1)
        # src_out =  torch.einsum("bcx,cdx->bdx",src_out, self.fno)
        # output = x * self.fft_linear1
        gate = x * self.fft_linear2
        output = self.freqPattern * self.gate(gate)
        output = torch.fft.irfft(output, dim=-1).transpose(1, 2)
        output = input + self.drop(self.act2(output))
        output = self.norm1(output)
        return output

    def forward(self, src, x_mark):
        # multi-scal
        multi = []  
        for i in range(len(self.conv_kernel)):
            # src_out, trend1 = self.decomp[i](src)
            # src_out, trend1 = self.decompse(src)
            # src_out = src
            # for k in range(src.shape[-1]):
            #     for j in range(src.shape[0]):
            #         # plt.plot(src[k, :, j].cpu().detach().numpy())
            #         plt.plot(src_out[k, :, j].cpu().detach().numpy())
            #         # plt.plot(trend1[k, :, j].cpu().detach().numpy())
            #         plt.show()
            # _, src_out = self.decomp[i](src)
            # sns.displot(data=src[:, :, :].reshape(-1).cpu().detach().numpy(), kde=True,
            #             stat='probability')
            #
            # sns.displot(data=src_out[:, :, :].reshape(-1).cpu().detach().numpy(), kde=True, stat='probability')
            # plt.show()

            # for i in range(src.shape[-1]):
            # # #     # plt.plot(tmp[:, :, i].mean(0).cpu().detach().numpy(), color='r')
            #     plt.plot(src[:, :, i].mean(0).cpu().detach().numpy(), color='g')
            #     plt.plot(src_out[:, :, i].mean(0).cpu().detach().numpy(), color='b')
            #     plt.show()
            #     sns.displot(data=src[:, :, i].reshape(-1).cpu().detach().numpy(),  kind="hist", aspect=1.4)
            #     sns.displot(data=src_out[:, :, i].reshape(-1).cpu().detach().numpy(), kind="hist", aspect=1.4)
            #     plt.show()
            #     plt.show()
            # src_out =src

            # src_out = self.conv_trans_conv(src, self.conv[i], self.conv_trans[i], self.isometric_conv[i], x_mark, self.time_conv[i])
            if self.mode == 'global':
                src_out = self.cal_global(src)
            elif self.mode =='local':
                src_out = self.conv_trans_conv(src, self.conv[i], self.conv_trans[i], self.isometric_conv[i], x_mark, self.time_conv[i])
            # gate = torch.clamp(self.Lambda, 0, 1)
            # src_out = out_loc*gate+ out_gl * (1-gate)

            multi.append(src_out)


        # merge
        # mg = torch.tensor([], device = self.device)
        # for i in range(len(self.conv_kernel)):
        #     mg = torch.cat((mg, multi[i].unsqueeze(1)), dim=1)
        # mg = self.merge(mg.permute(0,3,1,2)).squeeze(-2).permute(0,2,1)


        mg = multi[0]
        # mg, _ = self.decomp[0](mg)
        return self.fnn_norm(mg + self.fnn(mg))
        return mg


class Seasonal_Prediction(nn.Module):
    def __init__(self, embedding_size=512, n_heads=8, dropout=0.05, d_layers=1, decomp_kernel=[32], c_out=1,
                conv_kernel=[2, 4], isometric_kernel=[18, 6], mode=None, device='cuda'):
        super(Seasonal_Prediction, self).__init__()

        self.mic = nn.ModuleList([MIC(feature_size=embedding_size, n_heads=n_heads, dropout=dropout,
                                                   decomp_kernel=decomp_kernel,conv_kernel=conv_kernel, isometric_kernel=isometric_kernel, mode=mode, device=device)
                                      for i in range(d_layers)])

        self.projection = nn.Linear(embedding_size, c_out)

    def forward(self, dec, x_mark):
        for mic_layer in self.mic:
            dec = mic_layer(dec, x_mark)
        return self.projection(dec)


class RevIN(nn.Module):
    def __init__(self, num_features: int, eps=1e-5, affine=True, subtract_last=False):
        """
        :param num_features: the number of features or channels
        :param eps: a value added for numerical stability
        :param affine: if True, RevIN has learnable affine parameters
        """
        super(RevIN, self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.affine = affine
        self.subtract_last = subtract_last
        if self.affine:
            self._init_params()

    def forward(self, x, mode:str):
        if mode == 'norm':
            self._get_statistics(x)
            x = self._normalize(x)
        elif mode == 'denorm':
            x = self._denormalize(x)
        else: raise NotImplementedError
        return x

    def _init_params(self):
        # initialize RevIN params: (C,)
        self.affine_weight = nn.Parameter(torch.ones(self.num_features))
        self.affine_bias = nn.Parameter(torch.zeros(self.num_features))

    def _get_statistics(self, x):
        dim2reduce = tuple(range(1, x.ndim-1))
        if self.subtract_last:
            self.last = x[:,-1,:].unsqueeze(1)
        else:
            self.mean = torch.mean(x, dim=dim2reduce, keepdim=True).detach()
        self.stdev = torch.sqrt(torch.var(x, dim=dim2reduce, keepdim=True, unbiased=False) + self.eps).detach()

    def _normalize(self, x):
        if self.subtract_last:
            x = x - self.last
        else:
            x = x - self.mean
        x = x / self.stdev
        if self.affine:
            x = x * self.affine_weight
            x = x + self.affine_bias
        return x

    def _denormalize(self, x):
        if self.affine:
            x = x - self.affine_bias
            x = x / (self.affine_weight + self.eps*self.eps)
        x = x * self.stdev
        if self.subtract_last:
            x = x + self.last
        else:
            x = x + self.mean
        return x


class TVT(nn.Module):
    def __init__(self, seq_len, pred_len, n_heads, dropout, d_ff, in_channels, freq):
        super(TVT, self).__init__()
        self.embedding = nn.Linear(seq_len+pred_len, d_ff)
        # self.attention = MultiheadAttention(pred_len, n_heads, dropout=dropout, batch_first=True)
        # self.norm1 = nn.LayerNorm(seq_len)
        # self.norm2 = nn.LayerNorm(seq_len)
        self.norm1 = nn.BatchNorm1d(seq_len)
        self.norm2 = nn.BatchNorm1d(seq_len)
        self.dropout = nn.Dropout(dropout)
        self.ffn = FeedForwardNetwork(pred_len, d_ff, dropout)
        self.out = nn.Linear(d_ff, pred_len)
        self.act = nn.GELU()
        # self.pos = nn.Parameter(torch.zeros(1, in_channels, seq_len+pred_len))
        self.pred_len = pred_len
        freq_map = {'h': 4, 't': 5, 's': 6, 'm': 1, 'a': 1, 'w': 2, 'd': 3, 'b': 3}
        d_inp = freq_map[freq]
        self.embed = nn.Linear(d_inp, in_channels)
        self.norm = nn.LayerNorm(seq_len)
        self.channel_mix = nn.Conv1d(in_channels=in_channels, out_channels=in_channels, kernel_size=11, padding=5, stride=1)
        self.ema = EMA(in_channels, 1, dropout)



    def forward(self, x, x_mark):
        B, L, D = x.shape
        x = x.transpose(1, 2)

        zeros = torch.zeros([x.shape[0], x.shape[1], self.pred_len], device=x.device)
        x = torch.cat([x, zeros], dim=2)

        #x = x + self.dropout(self.act(self.ema(x)))

        pos = self.embed(x_mark).transpose(1, 2)
        x = x + pos

        x = self.embedding(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.out(x)
        x = self.act(x)

        # x = x + self.dropout(self.act(self.channel_mix(x)))
        # x = self.act(x)
        # x = self.dropout(x)
        # x = x + self.dropout(self.attention(x, x, x)[0])
        # x = self.norm1(x)
        # x = x + self.dropout(self.ffn(x))
        # x = x + self.dropout(self.ffn(x))
        x = x + self.ffn(x)
        #x = x + self.dropout(self.act(self.ema(x)))

        #
        x = x.transpose(1, 2)
        # x = self.norm2(x)
        # out = self.out(x).transpose(1, 2)
        return x
class TVT2(nn.Module):
    def __init__(self, seq_len, pred_len, n_heads, dropout, d_ff, in_channels, freq):
        super(TVT2, self).__init__()
        self.linear1 = nn.Linear(seq_len + pred_len, d_ff)
        self.linear2 = nn.Linear(seq_len + pred_len, d_ff)
        self.gate = nn.Sigmoid()
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        self.ffn = FeedForwardNetwork(pred_len, d_ff, dropout)
        self.out = nn.Linear(d_ff, pred_len)
        self.pred_len = pred_len
        freq_map = {'h': 4, 't': 5, 's': 6, 'm': 1, 'a': 1, 'w': 2, 'd': 3, 'b': 3}
        d_inp = freq_map[freq]
        self.embed = nn.Linear(d_inp, in_channels)

    def forward(self, x, x_mark):
        B, L, D = x.shape
        x = x.transpose(1, 2)
        zeros = torch.zeros([x.shape[0], x.shape[1], self.pred_len], device=x.device)
        x = torch.cat([x, zeros], dim=2)
        pos = self.embed(x_mark).transpose(1, 2)
        x = x + pos
        x = self.linear1(x) * self.gate(self.linear2(x))
        x = self.act(x)
        x = self.out(x)
        x = self.act(x)
        x = x + self.ffn(x)
        x = x.transpose(1, 2)
        return x

class Freq_TVT(nn.Module):
    def __init__(self,  seq_len, pred_len, dropout, n_heads, d_ff, in_channels, freq):
        super(Freq_TVT, self).__init__()
        freq_map = {'h': 4, 't': 5, 's': 6, 'm': 1, 'a': 1, 'w': 2, 'd': 3, 'b': 3}
        d_inp = freq_map[freq]
        self.embed = nn.Linear(d_inp, in_channels)
        self.pred_len = pred_len
        self.len = (seq_len + pred_len) //2 + 1
        # self.len = seq_len // 2 + 1
        self.output_len = seq_len + pred_len
        self.fno = nn.Parameter(0.02 * torch.randn(in_channels, self.len, self.len, dtype=torch.cfloat))
        self.bias = nn.Parameter(0.02 * torch.randn(in_channels, self.len, dtype=torch.cfloat))
        self.act = nn.GELU()
        self.ffn = FeedForwardNetwork(seq_len + pred_len, d_ff, dropout)
        self.drop = nn.Dropout(dropout)
        # self.channel_attention = MultiheadAttention(self.len, n_heads, dropout=dropout, batch_first=True)

        self.norm = nn.LayerNorm(d_ff)


    def forward(self, input, x_mark):
        B, L, D = input.shape
        input = input.transpose(1, 2)
        pos = self.embed(x_mark).transpose(1, 2)
        x = input + pos
        x_fft = torch.fft.rfft(x, dim=-1, norm='ortho')
        out_fft = torch.einsum("bcx,cxl->bcl", x_fft, self.fno) #+ self.bias
        x_fft = out_fft
        output = torch.fft.irfft(x_fft, dim=-1, n=self.output_len, norm='ortho')
        output = self.drop(self.act(self.ffn(output)))

        return output.transpose(1, 2)

# class NewTrend(nn.Module):
#     def __init__(self, seq_len, pred_len, dropout, featureSize, d_ff, in_channels, freq):
#         freq_map = {'h': 4, 't': 5, 's': 6, 'm': 1, 'a': 1, 'w': 2, 'd': 3, 'b': 3}
#         d_inp = freq_map[freq]
#         self.embed = nn.Linear(d_inp, in_channels)
#
#     def forward(self, input, x_mark):
#         B, L, D = input.shape





class PositionalEmbedding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEmbedding, self).__init__()
        # Compute the positional encodings once in log space.
        pe = torch.zeros(max_len, d_model).float()
        pe.require_grad = False

        position = torch.arange(0, max_len).float().unsqueeze(1)
        div_term = (torch.arange(0, d_model, 2).float() * -(math.log(10000.0) / d_model)).exp()

        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        pe = pe.unsqueeze(0)
        self.scale = nn.Parameter(torch.ones(d_model,))
        self.register_buffer('pe', pe)

    def forward(self, x):
        return self.pe[:, :x.size(1)]




# class AttentionLayer(nn.Module):
#     def __init__(self, d_model, n_heads, dropout):
#         super(AttentionLayer, self).__init__()
#         self.query_projection = nn.Linear(d_model, d_model)
#         self.key_projection = nn.Linear(d_model, d_model)
#         self.value_projection = nn.Linear(d_model,d_model)
#         self.out_projection = nn.Linear(d_model, d_model)
#         self.n_heads = n_heads
#         self.scale = (d_model // n_heads) ** -0.5
#
#     def forward(self, queries, keys, values):
#         B, L, _ = queries.shape
#         _, S, _ = keys.shape
#         H = self.n_heads
#
#         queries = self.query_projection(queries).view(B, L, H, -1)
#         keys = self.key_projection(keys).view(B, S, H, -1)
#         values = self.value_projection(values).view(B, S, H, -1)
#         scores = torch.einsum("blhe,bshe->bhls", queries, keys)
#         A = self.dropout(torch.softmax(self.scale * scores, dim=-1))
#         V = torch.einsum("bhls,bshd->blhd", A, values)
#         out = V.view(B, L, -1)
#
#         return self.out_projection(out)

class patchAttention(nn.Module):
    def __init__(self, seq_len, pred_len, in_channels, freq, d_model, patchSize, stride, n_heads, d_ff, dropout):
        super(patchAttention, self).__init__()
        freq_map = {'h': 4, 't': 5, 's': 6, 'm': 1, 'a': 1, 'w': 2, 'd': 3, 'b': 3}
        d_inp = freq_map[freq]
        self.embed = nn.Linear(d_inp, in_channels)
        self.pred_len = pred_len
        self.size = patchSize
        self.step = stride
        self.value_embed = nn.Linear(patchSize, d_model)
        self.attention = MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.len = seq_len + pred_len
        self.patch_num = int((self.len - patchSize)/stride + 1)
        self.ffn = FeedForwardNetwork(d_model, d_ff, dropout)
        self.norm = nn.LayerNorm([self.patch_num, d_model])
        self.norm2 = nn.LayerNorm([self.patch_num, d_model])
        self.norm3 = nn.LayerNorm([self.patch_num, d_model])
        self.act = nn.GELU()
        self.drop = nn.Dropout(dropout)
        self.project = nn.Linear(d_model*self.patch_num, pred_len + seq_len)
        self.W_pos_embed = nn.Parameter(torch.randn(self.patch_num, d_model) * 1e-2)


    def forward(self, input, x_mark):
        B, L, D = input.shape
        x = input.transpose(1, 2)
        zeros = torch.zeros([B, D, self.pred_len], device=x.device)
        x = torch.cat([x, zeros], dim=2)
        # x_mark = x_mark.unfold(dimension=1, size=self.size, step=self.step)
        # pos = self.embed(x_mark.reshape(B, self.patch_num, -1)).unsqueeze(dim=1)
        pos = self.embed(x_mark).transpose(1, 2)
        x = x + pos
        x = x.unfold(dimension=2, size=self.size, step=self.step)
        x = self.value_embed(x)

        B, D, S, H = x.shape
        x = x.view(-1, S, H)
        x = self.norm(x)
        x = x + self.drop(self.attention(x, x, x)[0])
        x = self.norm2(x)
        x = x + self.drop(self.ffn(x))
        x = self.norm3(x)
        x = x.view(B, D, -1)
        x = self.project(x)
        return x.transpose(1, 2)



def conv1d_fft(f, g, dim=-1):
    N = f.size(dim)
    M = g.size(dim)
    fast_len = next_fast_len(N + M - 1)
    F_f = torch.fft.rfft(f, fast_len, dim=dim)
    F_g = torch.fft.rfft(g, fast_len, dim=dim)
    F_fg = F_f * F_g.conj()
    out = torch.fft.irfft(F_fg, fast_len, dim=dim)
    out = out.roll((-1,), dims=(dim,))
    idx = torch.as_tensor(range(fast_len - N, fast_len)).to(out.device)
    out = out.index_select(dim, idx)
    return out

class EMA(nn.Module):
    def __init__(self, in_channels, featureSize, dropout):
        super(EMA, self).__init__()
        self.delta = nn.Parameter(torch.Tensor(in_channels, featureSize, 1))
        self.alpha = nn.Parameter(torch.Tensor(in_channels, featureSize, 1))
        self.beta = nn.Parameter(torch.Tensor(in_channels, featureSize, 1))
        self.h0 = nn.Parameter(torch.Tensor(in_channels, featureSize, 1))
        self.eta = nn.Parameter(torch.Tensor(in_channels, featureSize))
        self.scale = math.sqrt(1.0 / featureSize)
        self.drop = nn.Dropout(dropout)
        self.featureSize = featureSize
        self.reset_parameters()


    def reset_parameters(self):
        with torch.no_grad():
            nn.init.normal_(self.delta, mean=0.0, std=0.2)
            nn.init.normal_(self.alpha, mean=0.0, std=0.2)
            # beta [1, -1, 1, -1, ...] seems more stable.
            val = torch.ones(self.featureSize, 1)
            if self.featureSize > 1:
                idx = torch.tensor(list(range(1, self.featureSize, 2)))
                val.index_fill_(0, idx, -1.0)
            self.beta.normal_(mean=0.0, std=0.02).add_(val)
            nn.init.normal_(self.h0, mean=0.0, std=1.0)
            nn.init.normal_(self.eta, mean=0.0, std=1.0)


    def get_exponential_weight(self, length, p, q):
        # weight = torch.arange(length).to(p).view(1, 1, length) * torch.log(q)
        weight = torch.arange(length).to(p).view(length) * torch.log(q)
        weight = torch.exp(weight)
        init_weight = weight * q
        weight = weight * p
        weight = torch.flip(weight, dims=[-1])
        return weight, init_weight

    def calc_coeffs(self):
        delta = torch.sigmoid(self.delta)
        alpha = torch.sigmoid(self.alpha)
        q = 1.0 - alpha
        return alpha, q

    def forward(self, x):
        B, D, L = x.shape
        alpha, q= self.calc_coeffs()
        p = alpha * self.beta
        weight, init_weight = self.get_exponential_weight(L, p, q)
        weight = torch.einsum('dnl,dn->dl', weight, self.eta * self.scale)
        res = init_weight * self.h0
        res = torch.einsum('dnl,dn->dl', res, self.eta * self.scale)
        output = conv1d_fft(self.drop(x), weight, dim=-1)
        output = output + res
        return output.view(B, -1, L)




class ScaleNorm(nn.Module):
    def __init__(self, eps=1e-5):
        super(ScaleNorm, self).__init__()
        self.eps = eps
        self.scala = nn.Parameter(torch.ones(1))

    def forward(self, x):
        mean_square = (x ** 2).mean(dim=-1, keepdim=True)
        x = x * torch.rsqrt(mean_square + self.eps) * self.scala
        return x

if __name__=="__main__":
    #B, L, D
    input = torch.randn([4, 96, 7])
    ema = EMA(1, 1, 7, 16, 0.2)
    result = ema(input)
    print(result)




