import torch
import torch.nn as nn
from models.embed import DataEmbedding, DataEmbedding_wo_pos, TokenEmbedding
from models.local_global import Seasonal_Prediction, series_decomp_multi, series_decomp, RevIN, TVT, TVT2, Freq_TVT, patchAttention, EMA
from hgru import HgruRealV6
import matplotlib.pyplot as plt
from scipy.fftpack import next_fast_len
from models.ESM import ExponentialSmoothing

def cal_padding(input_len, seg_len):
    padding_len = seg_len - (input_len % seg_len) if input_len % seg_len != 0 else 0
    return padding_len

class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()

        self.pred_len = configs.pred_len
        self.seq_len = configs.seq_len
        self.c_out = configs.enc_in
        self.patch_len = configs.patch_len
        decomp_kernel = configs.decomp_kernel

        self.decomp_multi = series_decomp_multi(decomp_kernel)
        self.decomp = series_decomp(decomp_kernel[0])

        self.revin_layer = RevIN(configs.enc_in)
        self.revin_layer2 = RevIN(configs.enc_in)


        self.freq_tvt = Freq_TVT(configs.seq_len, configs.pred_len, configs.dropout, 128, configs.d_model * 2,
                                 configs.enc_in, configs.freq)



        self.trend = nn.Linear(self.seq_len, self.pred_len)
        self.hgru = HgruRealV6(configs.d_model)
        self.linear_patch = nn.Linear(self.patch_len, configs.d_model)
        self.linear_patch_re = nn.Linear(configs.d_model, self.patch_len)
        self.trend_padding = cal_padding(self.seq_len + self.pred_len, self.patch_len)
        self.time_shift = nn.ZeroPad2d((0, 0, 1, -1))
        self.dropout = nn.Dropout(configs.dropout)
        self.act = nn.GELU()
        # self.cla = cla_alpha('wavelet', 'haar')



    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, his_data,
                enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
        B, L, C = x_enc.shape
        seasonal_init_enc, trend = self.decomp_multi(x_enc)

        trend = self.revin_layer(trend, 'norm')
        pred_trend = self.trend(trend.transpose(1, 2)).transpose(1, 2)
        last = trend[:, -1, :].unsqueeze(1).repeat(1, self.trend_padding, 1)
        trend = torch.cat([trend, last], dim=1)
        trend = trend.unfold(dimension=1, size=self.patch_len, step=self.patch_len)
        trend = trend.permute(0, 2, 1, 3).reshape(B * C, -1, self.patch_len)
        trend_in = self.linear_patch(trend)
        trend_in = self.time_shift(trend_in)
        trend_out = self.hgru(trend_in)
        trend_out = self.linear_patch_re(self.dropout(trend_out))
        trend_out = trend_out.transpose(1, 2).reshape(B, C, -1).permute(0, 2, 1)
        trend_out = trend_out[:, :(self.seq_len + self.pred_len), :]
        trend_out = pred_trend + self.dropout(self.act(trend_out[:, -self.pred_len:, :]))
        trend_out = self.decomp_multi(trend_out)[1]
        trend = self.revin_layer(trend_out, 'denorm')

        zeros = torch.zeros([x_dec.shape[0], self.pred_len, x_dec.shape[2]], device=x_enc.device)
        seasonal_init_dec = torch.cat([seasonal_init_enc[:, -self.seq_len:, :], zeros], dim=1)
        dec_out = self.freq_tvt(seasonal_init_dec, x_mark_dec)

        dec_out = dec_out[:, -self.pred_len:, :] + trend[:, -self.pred_len:, :]
        # dec_out = trend[:, -self.pred_len:, :]

        return dec_out


if __name__=="__main__":
    a = torch.tensor([-1, 0, 1])

    print(a)